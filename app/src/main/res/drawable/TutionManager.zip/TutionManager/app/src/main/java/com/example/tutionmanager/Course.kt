package com.example.tutionmanager

data class Course(
    val id: String = "",
    val name: String = "",
    val teacherId: String = ""
)
